package ajedrez;

public class Reina {

}
