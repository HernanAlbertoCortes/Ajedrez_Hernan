package ajedrez;

public class Jugador {

}
