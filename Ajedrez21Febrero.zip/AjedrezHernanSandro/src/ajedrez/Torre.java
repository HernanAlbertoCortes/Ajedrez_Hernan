package ajedrez;

public class Torre {

}
