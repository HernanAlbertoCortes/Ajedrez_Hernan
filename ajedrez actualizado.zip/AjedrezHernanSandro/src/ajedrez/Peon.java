package ajedrez;

public class Peon {

}
