package ajedrez;

public interface Piezas {
	public String mover(boolean turno);
	public double comer();
}
