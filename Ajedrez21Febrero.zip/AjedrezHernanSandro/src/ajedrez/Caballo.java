package ajedrez;

public class Caballo {

}
