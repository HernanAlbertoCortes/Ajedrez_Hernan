package ajedrez;

public interface Piezas {
	public String mover();
	public double comer();
}
